export const LEVEL = {
  EASY: 16,
  MEDIUM: 20,
  HARD: 24,
};

export const TOPICS = {
  PEPE: "pepe",
  RICK: "rick-and-morty",
};
