import React from 'react';

const Title = () => {
  return (
    <h3 className="title">
      Memory Card game
    </h3>
  );
};

export default Title;
