export const SET_MODE = "SET_MODE";
export const UPDATE_TIME = "UPDATE_TIME";
export const UPDATE_MOVE = "UPDATE_MOVE";
export const UPDATE_DATA = "SET_INIT_DATA";
export const UPDATE_START = "UPDATE_START";
export const UPDATE_TOPIC = "UPDATE_TOPIC";
export const UPDATE_REMOVED = "UPDATE_REMOVED";
